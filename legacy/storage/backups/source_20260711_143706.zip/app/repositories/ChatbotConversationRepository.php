<?php
/**
 * ChatbotConversationRepository – Quản lý phiên trò chuyện và tin nhắn của Chatbot AI.
 * Tuân thủ SOLID, Repository Pattern.
 */
class ChatbotConversationRepository
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Tạo hoặc tìm cuộc hội thoại AI còn hoạt động.
     */
    public function getOrCreate(string $sessionId, ?int $userId): int
    {
        if ($userId) {
            $this->db->query("SELECT id FROM chatbot_conversations 
                              WHERE user_id = :uid AND status = 'active'
                              ORDER BY id DESC LIMIT 1");
            $this->db->bind(':uid', $userId);
        } else {
            $this->db->query("SELECT id FROM chatbot_conversations 
                              WHERE session_id = :sid AND status = 'active'
                              ORDER BY id DESC LIMIT 1");
            $this->db->bind(':sid', $sessionId);
        }

        $row = $this->db->single();
        if ($row) {
            return (int)$row->id;
        }

        // Tạo mới
        $this->db->query("INSERT INTO chatbot_conversations (user_id, session_id, status)
                          VALUES (:uid, :sid, 'active')");
        $this->db->bind(':uid', $userId);
        $this->db->bind(':sid', $sessionId);
        
        if ($this->db->execute()) {
            $this->db->query("SELECT LAST_INSERT_ID() as last_id");
            return (int)($this->db->single()->last_id ?? 0);
        }
        return 0;
    }

    public function findById(int $id): ?stdClass
    {
        $this->db->query("SELECT * FROM chatbot_conversations WHERE id = :id");
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        return $row ?: null;
    }

    public function listAll(): array
    {
        $this->db->query("SELECT c.*, nd.ten as user_name, nd.email as user_email
                          FROM chatbot_conversations c
                          LEFT JOIN nguoi_dung nd ON c.user_id = nd.id
                          ORDER BY c.id DESC LIMIT 100");
        return $this->db->resultSet();
    }

    public function getMessages(int $conversationId): array
    {
        $this->db->query("SELECT * FROM chatbot_messages 
                          WHERE conversation_id = :conv_id 
                          ORDER BY id ASC");
        $this->db->bind(':conv_id', $conversationId);
        return $this->db->resultSet();
    }

    public function addMessage(int $conversationId, string $role, string $message, ?string $sources = null): int
    {
        $this->db->query("INSERT INTO chatbot_messages (conversation_id, role, message, sources)
                          VALUES (:conv_id, :role, :msg, :sources)");
        $this->db->bind(':conv_id', $conversationId);
        $this->db->bind(':role',    $role);
        $this->db->bind(':msg',     $message);
        $this->db->bind(':sources', $sources);

        if ($this->db->execute()) {
            $this->db->query("SELECT LAST_INSERT_ID() as last_id");
            return (int)($this->db->single()->last_id ?? 0);
        }
        return 0;
    }

    public function updateStatus(int $id, string $status): bool
    {
        $this->db->query("UPDATE chatbot_conversations SET status = :status WHERE id = :id");
        $this->db->bind(':status', $status);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }
}
