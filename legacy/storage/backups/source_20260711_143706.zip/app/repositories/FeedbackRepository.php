<?php
/**
 * FeedbackRepository – Tương tác trực tiếp với bảng `chatbot_feedback` trong CSDL.
 * Tuân thủ SOLID, Repository Pattern.
 */
class FeedbackRepository
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function insert(array $data): int
    {
        $this->db->query("INSERT INTO chatbot_feedback (conversation_id, message_id, rating, feedback_text)
                          VALUES (:conv_id, :msg_id, :rating, :text)");
        
        $this->db->bind(':conv_id', $data['conversation_id']);
        $this->db->bind(':msg_id',  $data['message_id']);
        $this->db->bind(':rating',  $data['rating']);
        $this->db->bind(':text',    $data['feedback_text'] ?? null);

        if ($this->db->execute()) {
            $this->db->query("SELECT LAST_INSERT_ID() as last_id");
            return (int)($this->db->single()->last_id ?? 0);
        }
        return 0;
    }

    public function listAll(): array
    {
        $this->db->query("SELECT f.*, m.message as answer_text, c.user_id, nd.ten as user_name
                          FROM chatbot_feedback f
                          JOIN chatbot_messages m ON f.message_id = m.id
                          JOIN chatbot_conversations c ON f.conversation_id = c.id
                          LEFT JOIN nguoi_dung nd ON c.user_id = nd.id
                          ORDER BY f.id DESC LIMIT 100");
        return $this->db->resultSet();
    }

    /**
     * Trích xuất số liệu thống kê về độ hài lòng của AI Chatbot.
     */
    public function getStatistics(): array
    {
        $this->db->query("SELECT COUNT(*) as total,
                                 SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as helpful,
                                 SUM(CASE WHEN rating = -1 THEN 1 ELSE 0 END) as unhelpful
                          FROM chatbot_feedback");
        $row = $this->db->single();
        $total = (int)($row->total ?? 0);
        $helpful = (int)($row->helpful ?? 0);
        $unhelpful = (int)($row->unhelpful ?? 0);
        $satisfaction = $total > 0 ? round((100 * $helpful) / $total, 1) : 100.0;

        return [
            'total'        => $total,
            'helpful'      => $helpful,
            'unhelpful'    => $unhelpful,
            'satisfaction' => $satisfaction
        ];
    }
}
