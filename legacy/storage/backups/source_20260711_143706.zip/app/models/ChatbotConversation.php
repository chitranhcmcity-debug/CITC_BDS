<?php
/**
 * Model ChatbotConversation – Phiên hội thoại của người dùng với Chatbot AI.
 * Tuân thủ SOLID, Model Layer.
 */
class ChatbotConversation
{
    public int $id;
    public ?int $user_id = null;
    public string $session_id;
    public string $status;
    public string $created_at;

    public function __construct(array|object $data = [])
    {
        if (empty($data)) return;

        $dataArr = is_object($data) ? get_object_vars($data) : $data;

        $this->id = (int)($dataArr['id'] ?? 0);
        $this->user_id = isset($dataArr['user_id']) ? (int)$dataArr['user_id'] : null;
        $this->session_id = (string)($dataArr['session_id'] ?? '');
        $this->status = (string)($dataArr['status'] ?? 'active');
        $this->created_at = (string)($dataArr['created_at'] ?? date('Y-m-d H:i:s'));
    }
}
