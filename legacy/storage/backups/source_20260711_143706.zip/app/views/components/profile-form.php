<?php
/**
 * Component: Profile Form - Form cập nhật thông tin cá nhân.
 * @var object $user Thông tin người dùng
 */
?>
<form action="<?= URL_ROOT ?>/nguoi-dung/profile" method="POST" id="profile-form">
    <?= Csrf::field() ?>
    <input type="hidden" name="action" value="profile">

    <div class="row g-3.5">
        <!-- Họ tên -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Họ và tên <span class="text-danger">*</span></label>
            <input type="text" class="form-control select-flat" name="ten" value="<?= htmlspecialchars($user->ten) ?>" required minlength="2" maxlength="100">
        </div>

        <!-- Số điện thoại -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Số điện thoại</label>
            <input type="tel" class="form-control select-flat" name="dien_thoai" value="<?= htmlspecialchars($user->dien_thoai ?? '') ?>" placeholder="Ví dụ: 0912345678" pattern="[0-9]{10,11}">
        </div>

        <!-- Email (Read-only) -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Địa chỉ Email (Không được đổi)</label>
            <div class="input-group">
                <input type="email" class="form-control select-flat bg-light" value="<?= htmlspecialchars($user->email) ?>" readonly>
                <span class="input-group-text bg-light text-secondary">
                    <?php if(!empty($user->email_verified_at)): ?>
                        <i class="fa-solid fa-circle-check text-success me-1" title="Đã xác thực"></i> <span class="small text-success fw-semibold">Đã xác thực</span>
                    <?php else: ?>
                        <i class="fa-solid fa-circle-exclamation text-warning me-1" title="Chưa xác thực"></i> <span class="small text-warning fw-semibold">Chưa xác thực</span>
                    <?php endif; ?>
                </span>
            </div>
        </div>

        <!-- Loại tài khoản -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Loại tài khoản</label>
            <select class="form-select select-flat bg-light" readonly disabled>
                <option value="ca_nhan" <?= ($user->loai_tai_khoan ?? '') === 'ca_nhan' ? 'selected' : '' ?>>Cá nhân chính chủ</option>
                <option value="moi_gioi" <?= ($user->loai_tai_khoan ?? '') === 'moi_gioi' ? 'selected' : '' ?>>Nhà môi giới chuyên nghiệp</option>
                <option value="cong_ty" <?= ($user->loai_tai_khoan ?? '') === 'cong_ty' ? 'selected' : '' ?>>Văn phòng/Công ty BĐS</option>
            </select>
            <small class="text-muted">Liên hệ Quản trị viên nếu cần đổi loại tài khoản đặc thù.</small>
        </div>

        <!-- Ngày sinh -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Ngày sinh</label>
            <input type="date" class="form-control select-flat" name="ngay_sinh" value="<?= $user->ngay_sinh ?? '' ?>">
        </div>

        <!-- Giới tính -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Giới tính</label>
            <select class="form-select select-flat" name="gioi_tinh">
                <option value="">Chọn giới tính</option>
                <option value="nam" <?= ($user->gioi_tinh ?? '') === 'nam' ? 'selected' : '' ?>>Nam</option>
                <option value="nu" <?= ($user->gioi_tinh ?? '') === 'nu' ? 'selected' : '' ?>>Nữ</option>
                <option value="khac" <?= ($user->gioi_tinh ?? '') === 'khac' ? 'selected' : '' ?>>Khác</option>
            </select>
        </div>

        <!-- Địa chỉ -->
        <div class="col-md-12">
            <label class="form-label fw-bold text-secondary fs-7">Địa chỉ cư trú</label>
            <input type="text" class="form-control select-flat" name="dia_chi" value="<?= htmlspecialchars($user->dia_chi ?? '') ?>" placeholder="Ví dụ: Cầu Giấy, Hà Nội">
        </div>

        <!-- Nghề nghiệp -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Nghề nghiệp</label>
            <input type="text" class="form-control select-flat" name="nghe_nghiep" value="<?= htmlspecialchars($user->nghe_nghiep ?? '') ?>" placeholder="Ví dụ: Kỹ sư, Nhà đầu tư,...">
        </div>

        <!-- Khu vực hoạt động -->
        <div class="col-md-6">
            <label class="form-label fw-bold text-secondary fs-7">Khu vực hoạt động kinh doanh chính</label>
            <input type="text" class="form-control select-flat" name="khu_vuc_hoat_dong" value="<?= htmlspecialchars($user->khu_vuc_hoat_dong ?? '') ?>" placeholder="Ví dụ: Nam Từ Liêm, Hoài Đức,...">
        </div>

        <!-- Giới thiệu bản thân -->
        <div class="col-md-12">
            <label class="form-label fw-bold text-secondary fs-7">Mô tả giới thiệu bản thân</label>
            <textarea class="form-control select-flat" name="mo_ta_ca_nhan" rows="4" placeholder="Mô tả tóm tắt kỹ năng, uy tín của bạn để thu hút khách hàng giao dịch..."><?= htmlspecialchars($user->mo_ta_ca_nhan ?? '') ?></textarea>
        </div>

        <!-- Ngày tham gia (Read-only) -->
        <div class="col-md-12 text-secondary fs-7.5">
            <i class="fa-solid fa-clock me-1"></i> Ngày gia nhập cộng đồng: <strong><?= date('d/m/Y', strtotime($user->ngay_tao)) ?></strong>
        </div>

        <!-- Nút lưu -->
        <div class="col-md-12 mt-4 text-end">
            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow-sm fw-bold">
                <i class="fa-solid fa-floppy-disk me-1.5"></i>Lưu thông tin hồ sơ
            </button>
        </div>
    </div>
</form>
