<?php
/**
 * View: Profile Index - Trang quản lý hồ sơ chính.
 * Hỗ trợ tab 'info' và tab 'security' để mang lại trải nghiệm liền mạch.
 * @var object $user Thông tin người dùng
 */
require_once APP_ROOT . '/app/views/layouts/header.php';

$activeTab = $_GET['tab'] ?? 'info';
?>

<div class="container py-4">
    <div class="row">
        <!-- Sidebar Menu (Left Column) -->
        <?php require_once APP_ROOT . '/app/views/nguoi-dung/sidebar.php'; ?>

        <!-- Main Content (Right Column) -->
        <div class="col-lg-9 col-md-8">
            
            <!-- Success/Error Messages -->
            <?php if (Session::get('success')): ?>
                <div class="alert alert-success alert-dismissible fade show border-0 shadow-xs" role="alert" style="border-radius: 12px;">
                    <i class="fa-solid fa-circle-check me-2"></i><strong>Thành công!</strong> <?= Session::get('success'); Session::delete('success'); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (Session::get('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show border-0 shadow-xs" role="alert" style="border-radius: 12px;">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i><strong>Lỗi!</strong> <?= Session::get('error'); Session::delete('error'); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Sub Tab Navigation -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px; overflow: hidden;">
                <div class="card-body p-0">
                    <ul class="nav nav-tabs nav-justified border-0" id="profileTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link py-3.5 border-0 fw-bold d-flex align-items-center justify-content-center <?= $activeTab === 'info' ? 'active text-primary bg-white' : 'text-secondary bg-light' ?>" 
                               href="?tab=info" role="tab">
                                <i class="fa-solid fa-user-pen me-2"></i>Thông tin cá nhân
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link py-3.5 border-0 fw-bold d-flex align-items-center justify-content-center <?= $activeTab === 'security' ? 'active text-primary bg-white' : 'text-secondary bg-light' ?>" 
                               href="?tab=security" role="tab">
                                <i class="fa-solid fa-user-shield me-2"></i>Bảo mật & Xác thực
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Tab Contents -->
            <div class="tab-content" id="profileTabContent">
                <?php if ($activeTab === 'info'): ?>
                    <!-- Tab: Personal Info -->
                    <div class="row">
                        <!-- Avatar Column (Left side) -->
                        <div class="col-lg-4 col-12">
                            <?php require_once APP_ROOT . '/app/views/components/avatar.php'; ?>
                        </div>
                        <!-- Profile Form Column (Right side) -->
                        <div class="col-lg-8 col-12">
                            <div class="card border-0 shadow-sm p-4" style="border-radius: 16px;">
                                <div class="card-body">
                                    <h4 class="fw-bold text-dark mb-4"><i class="fa-solid fa-id-card text-primary me-2"></i>Thông tin tài khoản</h4>
                                    <?php require_once APP_ROOT . '/app/views/components/profile-form.php'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php elseif ($activeTab === 'security'): ?>
                    <!-- Tab: Security & Privacy -->
                    <?php require_once APP_ROOT . '/app/views/profile/security.php'; ?>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<style>
/* CSS Tinh tế cho Tab Navigation */
#profileTab .nav-link {
    transition: all 0.2s ease;
    border-radius: 0;
}
#profileTab .nav-link.active {
    border-bottom: 3px solid var(--bs-primary) !important;
}
#profileTab .nav-link:hover:not(.active) {
    background-color: #eaeaea !important;
    color: var(--bs-dark) !important;
}
</style>

<?php require_once APP_ROOT . '/app/views/layouts/footer.php'; ?>
