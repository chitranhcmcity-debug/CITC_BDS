<?php require_once '../app/views/admin/layouts/header.php'; ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Cài Đặt Hệ Thống</h1>
    <button class="btn btn-sm btn-success"><i class="fa-solid fa-floppy-disk me-1"></i> Lưu Cài Đặt</button>
</div>

<div class="card border-0 shadow-sm rounded-3 mb-4">
    <div class="card-header bg-white border-bottom-0 pt-3 pb-0">
        <h5 class="mb-0 text-primary"><i class="fa-solid fa-globe me-2"></i> Thông Tin Website</h5>
    </div>
    <div class="card-body">
        <form action="<?= URL_ROOT ?>/admin/cai-dat/save" method="POST">
            <?= Csrf::field() ?>
            <div class="mb-3">
                <label class="form-label fw-bold">Tên Website</label>
                <input type="text" name="site_name" class="form-control" value="<?= htmlspecialchars($data['settings']['site_name'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Địa Chỉ Giao Dịch</label>
                <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($data['settings']['address'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Số Hotline Liên Hệ</label>
                <input type="text" name="hotline" class="form-control" value="<?= htmlspecialchars($data['settings']['hotline'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Email Nhận Thông Báo</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($data['settings']['email'] ?? '') ?>">
            </div>
            
            <hr class="my-4">
            
            <h5 class="mb-3 text-primary"><i class="fa-solid fa-share-nodes me-2"></i> Mạng Xã Hội</h5>
            <div class="mb-3">
                <label class="form-label fw-bold">Link Facebook</label>
                <input type="url" name="facebook" class="form-control" value="<?= htmlspecialchars($data['settings']['facebook'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Link Zalo (VD: https://zalo.me/sdt)</label>
                <input type="url" name="zalo" class="form-control" value="<?= htmlspecialchars($data['settings']['zalo'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Link YouTube</label>
                <input type="url" name="youtube" class="form-control" value="<?= htmlspecialchars($data['settings']['youtube'] ?? '') ?>">
            </div>

            <hr class="my-4">
            
            <h5 class="mb-3 text-primary"><i class="fa-solid fa-robot me-2"></i> Cấu Hình AI Chatbot (Google Gemini)</h5>
            <div class="mb-3">
                <label class="form-label fw-bold">Gemini API Key</label>
                <input type="password" name="gemini_api_key" class="form-control" value="" autocomplete="new-password" placeholder="Để trống nếu không thay đổi API Key">
                <div class="form-text text-muted">API Key được lưu trữ bảo mật trên máy chủ và ẩn khỏi giao diện khách truy cập. Lấy key miễn phí tại <a href="https://aistudio.google.com/" target="_blank">Google AI Studio</a>.</div>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Model AI</label>
                <select name="gemini_model" class="form-select">
                    <option value="gemini-2.5-flash" <?= ($data['settings']['gemini_model'] ?? '') === 'gemini-2.5-flash' ? 'selected' : '' ?>>Gemini 2.5 Flash (Nhanh & đề xuất)</option>
                    <option value="gemini-2.5-flash-lite" <?= ($data['settings']['gemini_model'] ?? '') === 'gemini-2.5-flash-lite' ? 'selected' : '' ?>>Gemini 2.5 Flash-Lite (Tối ưu tài nguyên)</option>
                    <option value="gemini-1.5-flash" <?= ($data['settings']['gemini_model'] ?? '') === 'gemini-1.5-flash' ? 'selected' : '' ?>>Gemini 1.5 Flash (Ổn định)</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Chỉ Dẫn Hệ Thống (System Instruction)</label>
                <textarea name="gemini_system_instruction" class="form-control" rows="5" placeholder="Nhập chỉ dẫn hành vi cho AI..."><?= htmlspecialchars($data['settings']['gemini_system_instruction'] ?? '') ?></textarea>
                <div class="form-text text-muted">Chỉ dẫn cho AI về vai trò, giọng điệu, cách ứng xử và quy tắc trả lời khách hàng. Hệ thống sẽ tự động đính kèm danh sách các dự án bất động sản thực tế mới nhất vào cuối phần này làm dữ liệu tham khảo để AI tự tư vấn.</div>
            </div>

            <hr class="my-4">
            
            <h5 class="mb-3 text-primary"><i class="fa-solid fa-envelope me-2"></i> Cấu Hình Email (SMTP)</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">SMTP Server (Host)</label>
                    <input type="text" name="smtp_host" class="form-control" value="<?= htmlspecialchars($data['settings']['smtp_host'] ?? '') ?>" placeholder="Ví dụ: smtp.gmail.com">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">SMTP Port</label>
                    <input type="number" name="smtp_port" class="form-control" value="<?= htmlspecialchars($data['settings']['smtp_port'] ?? '587') ?>" placeholder="587 hoặc 465">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">Mã Hóa (Encryption)</label>
                    <select name="smtp_secure" class="form-select">
                        <option value="none" <?= ($data['settings']['smtp_secure'] ?? '') === 'none' ? 'selected' : '' ?>>Không mã hóa (None)</option>
                        <option value="tls" <?= ($data['settings']['smtp_secure'] ?? 'tls') === 'tls' ? 'selected' : '' ?>>TLS (Đề xuất)</option>
                        <option value="ssl" <?= ($data['settings']['smtp_secure'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Xác Thực SMTP (SMTP Auth)</label>
                    <div class="form-check form-switch mt-2">
                        <input type="checkbox" name="smtp_auth" class="form-check-input" id="smtp_auth" value="1" <?= ($data['settings']['smtp_auth'] ?? '') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="smtp_auth">Yêu cầu xác thực tài khoản</label>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Tài Khoản SMTP (Username)</label>
                    <input type="text" name="smtp_user" class="form-control" value="<?= htmlspecialchars($data['settings']['smtp_user'] ?? '') ?>" placeholder="Tài khoản email gửi thư">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Mật Khẩu SMTP (Password)</label>
                    <input type="password" name="smtp_pass" class="form-control" value="" autocomplete="new-password" placeholder="Để trống nếu không thay đổi mật khẩu ứng dụng">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Email Người Gửi (From Email)</label>
                    <input type="email" name="smtp_from_email" class="form-control" value="<?= htmlspecialchars($data['settings']['smtp_from_email'] ?? '') ?>" placeholder="Để trống nếu giống Tài Khoản SMTP">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tên Người Gửi (From Name)</label>
                    <input type="text" name="smtp_from_name" class="form-control" value="<?= htmlspecialchars($data['settings']['smtp_from_name'] ?? '') ?>" placeholder="Ví dụ: TimNhaDat.site">
                </div>
            </div>

            <!-- Gửi Thử Email Card/Block -->
            <div class="bg-light p-3 rounded-3 mb-3 border">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <label class="form-label fw-bold mb-1"><i class="fa-solid fa-vial-circle-check text-primary me-1"></i> Kiểm tra kết nối gửi thư (SMTP Test)</label>
                        <div class="input-group">
                            <input type="email" id="test_email" class="form-control" placeholder="Nhập địa chỉ email nhận...">
                            <button type="button" class="btn btn-primary" id="btn-test-email"><i class="fa-solid fa-paper-plane me-1"></i> Gửi Thử</button>
                        </div>
                        <div class="form-text text-muted">Vui lòng nhấn <strong>Lưu Cài Đặt</strong> trước khi thực hiện gửi thử để áp dụng cấu hình mới nhất.</div>
                    </div>
                    <div class="col-md-4">
                        <div id="test-email-status" class="mt-2 mt-md-0 fw-bold" style="display:none; font-size: 0.9rem;"></div>
                    </div>
                </div>
            </div>

            <div class="text-end mt-4">
                <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk me-1"></i> Lưu Cài Đặt</button>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4"><div class="card-header bg-white fw-bold"><i class="fa-solid fa-images me-2 text-info"></i>Tải Logo & Favicon</div><div class="card-body row g-3"><div class="col-md-6"><form action="<?=URL_ROOT?>/admin/cai-dat/upload-logo" method="POST" enctype="multipart/form-data"><?=Csrf::field()?><label class="form-label fw-semibold">Logo website</label><div class="input-group"><input type="file" name="logo" class="form-control" accept="image/png,image/jpeg,image/webp"><button class="btn btn-info text-white">Tải logo</button></div></form></div><div class="col-md-6"><form action="<?=URL_ROOT?>/admin/cai-dat/upload-favicon" method="POST" enctype="multipart/form-data"><?=Csrf::field()?><label class="form-label fw-semibold">Favicon</label><div class="input-group"><input type="file" name="favicon" class="form-control" accept="image/png,image/x-icon,image/vnd.microsoft.icon"><button class="btn btn-info text-white">Tải favicon</button></div></form></div></div></div>

<form action="<?= URL_ROOT ?>/admin/cai-dat/save" method="POST" class="card border-0 shadow-sm mb-4">
<?= Csrf::field() ?><div class="card-header bg-white fw-bold"><i class="fa-solid fa-sliders me-2 text-primary"></i>Cấu hình mở rộng</div><div class="card-body"><div class="accordion" id="extendedSettings">
<?php $groups=[
'website'=>['Thông tin & giao diện',['slogan'=>'Slogan','description'=>'Mô tả website','tiktok'=>'TikTok','copyright'=>'Copyright','logo'=>'Logo','logo_dark'=>'Logo Dark','logo_light'=>'Logo Light','favicon'=>'Favicon','default_banner'=>'Banner mặc định','share_image'=>'Ảnh chia sẻ']],
'seo'=>['SEO & Analytics',['meta_title'=>'Meta title','meta_description'=>'Meta description','keywords'=>'Keywords','canonical'=>'Canonical URL','robots'=>'Robots','sitemap'=>'Sitemap','google_search_console'=>'Google Search Console','google_analytics'=>'Google Analytics','facebook_pixel'=>'Facebook Pixel']],
'payment'=>['PayOS & Google Maps',['payos_client_id'=>'PayOS Client ID','payos_api_key'=>'PayOS API Key','payos_checksum_key'=>'PayOS Checksum Key','payos_return_url'=>'Return URL','payos_webhook_url'=>'Webhook URL','google_maps_key'=>'Google Maps API Key']],
'ai'=>['Nhà cung cấp AI',['openai_api_key'=>'OpenAI API Key','gemini_api_key'=>'Gemini API Key','claude_api_key'=>'Claude API Key','deepseek_api_key'=>'DeepSeek API Key']],
'upload'=>['Upload',['upload_max_mb'=>'Dung lượng tối đa (MB)','image_extensions'=>'Định dạng ảnh','video_extensions'=>'Định dạng video','document_extensions'=>'Định dạng tài liệu','upload_path'=>'Đường dẫn upload']]
]; foreach($groups as$key=>$g):?><div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button <?=$key==='website'?'':'collapsed'?>" type="button" data-bs-toggle="collapse" data-bs-target="#set-<?=$key?>"><?=$g[0]?></button></h2><div id="set-<?=$key?>" class="accordion-collapse collapse <?=$key==='website'?'show':''?>" data-bs-parent="#extendedSettings"><div class="accordion-body"><div class="row g-3"><?php foreach($g[1] as$name=>$label):$secret=str_contains($name,'key');?><div class="col-md-6"><label class="form-label fw-semibold"><?=$label?></label><?php if(in_array($name,['description','meta_description','robots'],true)):?><textarea name="<?=$name?>" class="form-control" rows="2"><?=htmlspecialchars($data['settings'][$name]??'')?></textarea><?php else:?><input type="<?=$secret?'password':($name==='upload_max_mb'?'number':'text')?>" name="<?=$name?>" class="form-control" value="<?=$secret?'':htmlspecialchars($data['settings'][$name]??'')?>" placeholder="<?=$secret?'Để trống nếu không thay đổi':''?>"><?php endif;?></div><?php endforeach;?></div><?php if($key==='ai'):?><div class="row mt-3"><?php foreach(['openai'=>'OpenAI','gemini'=>'Gemini','claude'=>'Claude','deepseek'=>'DeepSeek'] as$ai=>$label):?><div class="col-md-3"><div class="form-check form-switch"><input type="hidden" name="<?=$ai?>_enabled" value="0"><input class="form-check-input" type="checkbox" name="<?=$ai?>_enabled" value="1" <?=($data['settings'][$ai.'_enabled']??'0')==='1'?'checked':''?>><label class="form-check-label">Bật <?=$label?></label></div></div><?php endforeach;?></div><?php endif;?><?php if($key==='payment'):?><div class="mt-3"><button type="button" class="btn btn-outline-primary" id="btn-test-payos"><i class="fa-solid fa-plug me-1"></i>Kiểm tra kết nối PayOS</button><span id="payos-test-status" class="small ms-2"></span><div class="form-text">Hãy lưu cấu hình trước khi kiểm tra.</div></div><?php endif;?></div></div></div><?php endforeach;?></div><div class="text-end mt-3"><button class="btn btn-success px-4"><i class="fa-solid fa-floppy-disk me-1"></i>Lưu cấu hình mở rộng</button></div></div></form>

<div class="row g-3 mb-4">
  <div class="col-lg-4"><div class="card border-0 shadow-sm h-100"><div class="card-header bg-white fw-bold"><i class="fa-solid fa-broom me-2 text-warning"></i>Quản lý Cache</div><div class="card-body d-flex flex-wrap gap-2"><?php foreach(['all'=>'Tất cả','config'=>'Cấu hình','route'=>'Route','view'=>'Giao diện'] as$type=>$label):?><form action="<?=URL_ROOT?>/admin/cai-dat/cache-clear" method="POST"><?=Csrf::field()?><input type="hidden" name="type" value="<?=$type?>"><button class="btn btn-outline-warning btn-sm" onclick="return confirm('Xóa cache <?=$label?>?')"><?=$label?></button></form><?php endforeach;?></div></div></div>
  <div class="col-lg-8"><div class="card border-0 shadow-sm h-100"><div class="card-header bg-white"><div class="d-flex flex-wrap justify-content-between align-items-center gap-2"><span class="fw-bold"><i class="fa-solid fa-database me-2 text-success"></i>Sao lưu hệ thống</span><div class="d-flex flex-wrap gap-1"><?php foreach(['database'=>'Cơ sở dữ liệu','uploads'=>'Tệp tải lên','source'=>'Mã nguồn','full'=>'Toàn bộ'] as$type=>$label):?><form action="<?=URL_ROOT?>/admin/cai-dat/backup" method="POST"><?=Csrf::field()?><input type="hidden" name="type" value="<?=$type?>"><button class="btn btn-success btn-sm" onclick="return confirm('Tạo bản sao lưu <?=$label?>?')"><?=$label?></button></form><?php endforeach;?></div></div></div><div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>File</th><th>Loại</th><th>Dung lượng</th><th>Người tạo</th><th>Thời gian</th><th class="text-end">Thao tác</th></tr></thead><tbody><?php foreach(($data['backups']??[]) as$b):?><tr><td class="small"><?=htmlspecialchars($b->file_name)?></td><td><span class="badge bg-light text-dark border"><?=htmlspecialchars($b->type)?></span></td><td><?=number_format($b->file_size/1024,1)?> KB</td><td><?=htmlspecialchars($b->creator??'Quản trị viên')?></td><td><?=date('d/m/Y H:i',strtotime($b->created_at))?></td><td class="text-end"><a class="btn btn-outline-primary btn-sm" href="<?=URL_ROOT?>/admin/cai-dat/download-backup/<?=$b->id?>" title="Tải xuống"><i class="fa-solid fa-download"></i></a><form class="d-inline" method="POST" action="<?=URL_ROOT?>/admin/cai-dat/delete-backup/<?=$b->id?>" onsubmit="return confirm('Xóa bản sao lưu này?')"><?=Csrf::field()?><button class="btn btn-outline-danger btn-sm" title="Xóa"><i class="fa-solid fa-trash"></i></button></form></td></tr><?php endforeach;?><?php if(empty($data['backups'])):?><tr><td colspan="6" class="text-center text-muted py-3">Chưa có bản sao lưu</td></tr><?php endif;?></tbody></table></div></div></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const btnTest = document.getElementById('btn-test-email');
    const inputEmail = document.getElementById('test_email');
    const statusDiv = document.getElementById('test-email-status');

    if (btnTest) {
        btnTest.addEventListener('click', function() {
            const emailVal = inputEmail.value.trim();
            if (!emailVal) {
                alert('Vui lòng nhập địa chỉ email nhận để gửi thử!');
                return;
            }

            // Simple email validation regex
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(emailVal)) {
                alert('Vui lòng nhập một địa chỉ email hợp lệ!');
                return;
            }

            btnTest.disabled = true;
            const originalText = btnTest.innerHTML;
            btnTest.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Đang gửi...';
            statusDiv.style.display = 'block';
            statusDiv.className = 'mt-2 mt-md-0 fw-bold text-warning';
            statusDiv.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Đang kết nối SMTP và gửi thư...';

            const formData = new FormData();
            formData.append('test_email', emailVal);
            formData.append('_csrf_token', '<?= Csrf::token() ?>');

            fetch('<?= URL_ROOT ?>/admin/cai-dat/testEmail', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Lỗi phản hồi từ máy chủ.');
                }
                return response.json();
            })
            .then(data => {
                btnTest.disabled = false;
                btnTest.innerHTML = originalText;
                if (data.success) {
                    statusDiv.className = 'mt-2 mt-md-0 fw-bold text-success';
                    statusDiv.innerHTML = '<i class="fa-solid fa-circle-check me-1"></i> ' + data.message;
                } else {
                    statusDiv.className = 'mt-2 mt-md-0 fw-bold text-danger';
                    statusDiv.innerHTML = '<i class="fa-solid fa-circle-xmark me-1"></i> ' + data.message;
                }
            })
            .catch(error => {
                btnTest.disabled = false;
                btnTest.innerHTML = originalText;
                statusDiv.className = 'mt-2 mt-md-0 fw-bold text-danger';
                statusDiv.innerHTML = '<i class="fa-solid fa-circle-xmark me-1"></i> Lỗi hệ thống: ' + error.message;
                console.error(error);
            });
        });
    }

    const payosButton = document.getElementById('btn-test-payos');
    const payosStatus = document.getElementById('payos-test-status');
    if (payosButton) payosButton.addEventListener('click', function () {
        payosButton.disabled = true;
        payosStatus.className = 'small ms-2 text-warning';
        payosStatus.textContent = 'Đang kiểm tra...';
        const body = new FormData(); body.append('_csrf_token', '<?= Csrf::token() ?>');
        fetch('<?= URL_ROOT ?>/admin/cai-dat/test-payos', {method:'POST', body})
          .then(response => response.json())
          .then(data => { payosStatus.className = 'small ms-2 ' + (data.success ? 'text-success' : 'text-danger'); payosStatus.textContent = data.message; })
          .catch(() => { payosStatus.className = 'small ms-2 text-danger'; payosStatus.textContent = 'Không thể kết nối máy chủ.'; })
          .finally(() => { payosButton.disabled = false; });
    });
});
</script>

<?php require_once '../app/views/admin/layouts/footer.php'; ?>
