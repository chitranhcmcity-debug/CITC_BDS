<?php require_once '../app/views/admin/layouts/header.php'; ?>
<link rel="stylesheet" href="<?= URL_ROOT ?>/public/css/chatbot.css?v=<?= filemtime(APP_ROOT . '/public/css/chatbot.css') ?>">

<div class="content-wrapper p-3 bg-light">
    <!-- Tiêu đề trang -->
    <section class="content-header mb-4">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h1 class="h3 fw-bold text-dark mb-1"><i class="fa-solid fa-robot text-primary me-2"></i>Quản trị Trợ lý ảo AI</h1>
                    <p class="text-muted mb-0 small">Huấn luyện dữ liệu (Knowledge Base), tinh chỉnh prompt chỉ dẫn và giám sát phản hồi khách hàng.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Thống kê AI Analytics -->
    <section class="content mb-4">
        <div class="row g-3">
            <div class="col-md-3 col-6">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-uppercase small fw-bold text-muted d-block mb-1">Tổng cuộc hội thoại</span>
                    <h3 class="fw-bold mb-0 text-dark"><?= number_format($stats['conversations_count']) ?></h3>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-uppercase small fw-bold text-muted d-block mb-1">Số câu hỏi tiếp nhận</span>
                    <h3 class="fw-bold mb-0 text-success"><?= number_format($stats['questions_count']) ?></h3>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-uppercase small fw-bold text-muted d-block mb-1">Mức hài lòng (Satisfaction)</span>
                    <h3 class="fw-bold mb-0 text-warning"><?= $stats['satisfaction_rate'] ?>%</h3>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-uppercase small fw-bold text-muted d-block mb-1">Tỷ lệ gặp CSKH (Transfer)</span>
                    <h3 class="fw-bold mb-0 text-primary"><?= $stats['transfer_rate'] ?>%</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- Quản lý Prompt & Tri thức -->
    <section class="content">
        <div class="row g-4">
            <!-- Cấu hình Prompt Chỉ dẫn hệ thống -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
                    <div class="card-header bg-white border-0 pt-3">
                        <h5 class="card-title fw-bold mb-0 text-dark"><i class="fa-solid fa-gears text-success me-2"></i>Cấu hình Prompt AI</h5>
                    </div>
                    <div class="card-body">
                        <!-- Flash message -->
                        <?php if (isset($_SESSION['flash_success'])): ?>
                            <div class="alert alert-success alert-dismissible fade show small py-2" role="alert">
                                <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
                                <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($_SESSION['flash_error'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show small py-2" role="alert">
                                <?= $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
                                <button type="button" class="btn-close py-2" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <form action="<?= URL_ROOT ?>/admin/chatbot/save-prompt" method="POST">
                            <?= Csrf::field() ?>
                            <div class="mb-3 text-start">
                                <label class="form-label small fw-bold text-secondary mb-1">Chỉ dẫn hệ thống của AI (System Instruction)</label>
                                <textarea name="content" rows="8" class="form-control form-control-sm text-secondary" style="font-size: 0.85rem;" required><?= htmlspecialchars($promptContent) ?></textarea>
                                <small class="text-muted d-block mt-1">Câu lệnh này định hình tính cách và phương thức trả lời của AI. Tránh Prompt Injection.</small>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary w-100 fw-bold py-2 shadow-sm">
                                <i class="fa-solid fa-save me-1"></i> Lưu cấu hình Prompt
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Thống kê phản hồi Feedback của người dùng -->
                <div class="card border-0 shadow-sm rounded-3 bg-white">
                    <div class="card-header bg-white border-0 pt-3">
                        <h5 class="card-title fw-bold mb-0 text-dark"><i class="fa-solid fa-comments text-warning me-2"></i>Phản hồi đánh giá AI</h5>
                    </div>
                    <div class="card-body p-0" style="max-height: 280px; overflow-y: auto;">
                        <ul class="list-group list-group-flush small text-start">
                            <?php if (empty($feedbacks)): ?>
                                <li class="list-group-item text-center py-4 text-muted">Chưa có phản hồi nào.</li>
                            <?php else: ?>
                                <?php foreach ($feedbacks as $fb): ?>
                                    <li class="list-group-item p-3 border-bottom">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span class="fw-bold text-dark"><?= htmlspecialchars($fb->user_name ?: 'Khách vãng lai') ?></span>
                                            <span class="badge bg-<?= $fb->rating === 1 ? 'success' : 'danger' ?>">
                                                <?= $fb->rating === 1 ? '👍 Hữu ích' : '👎 Không hữu ích' ?>
                                            </span>
                                        </div>
                                        <div class="text-secondary small mb-1">AI: *<?= htmlspecialchars($fb->answer_text) ?>*</div>
                                        <?php if ($fb->feedback_text): ?>
                                            <div class="bg-light p-2 rounded text-dark border-start border-3 border-warning mt-1">
                                                Ý kiến: <?= htmlspecialchars($fb->feedback_text) ?>
                                            </div>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Cơ sở tri thức (Knowledge Base) -->
            <div class="col-lg-7">
                <div class="card border-0 shadow-sm rounded-3 bg-white">
                    <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                        <h5 class="card-title fw-bold mb-0 text-dark"><i class="fa-solid fa-book-open text-primary me-2"></i>Cơ sở tri thức (Knowledge Base)</h5>
                        <button class="btn btn-sm btn-success fw-bold rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#addKnowledgeModal">
                            <i class="fa-solid fa-plus me-1"></i> Thêm tài liệu
                        </button>
                    </div>

                    <div class="card-body p-0 mt-2">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 text-start" style="font-size: 0.88rem;">
                                <thead class="table-light text-secondary small fw-bold">
                                    <tr>
                                        <th class="ps-3" style="width: 50px;">ID</th>
                                        <th style="width: 100px;">Phân loại</th>
                                        <th>Tiêu đề tri thức</th>
                                        <th style="width: 80px;">Trạng thái</th>
                                        <th class="text-end pe-3" style="width: 120px;">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($articles)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-4 text-muted">
                                                Chưa có tài liệu tri thức nào được nạp.
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($articles as $art): ?>
                                            <tr>
                                                <td class="ps-3 fw-semibold text-secondary">#<?= $art->id ?></td>
                                                <td>
                                                    <span class="badge bg-light text-secondary border">
                                                        <?= strtoupper($art->category) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <strong class="d-block text-dark"><?= htmlspecialchars($art->title) ?></strong>
                                                    <span class="text-muted d-block small text-truncate" style="max-width: 250px;">
                                                        <?= htmlspecialchars($art->content) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?= $art->is_active ? 'success' : 'secondary' ?>">
                                                        <?= $art->is_active ? 'Bật' : 'Tắt' ?>
                                                    </span>
                                                </td>
                                                <td class="text-end pe-3">
                                                    <div class="d-flex gap-1 justify-content-end">
                                                        <!-- Nút Sửa -->
                                                        <button onclick='openEditKnowledgeModal(<?= json_encode($art) ?>)' class="btn btn-xs btn-outline-primary py-1 px-2 rounded">
                                                            <i class="fa-solid fa-edit"></i>
                                                        </button>
                                                        
                                                        <!-- Nút Xóa -->
                                                        <form action="<?= URL_ROOT ?>/admin/chatbot/delete-knowledge/<?= $art->id ?>" method="POST" onsubmit="return confirm('Bạn có chắc muốn xóa tri thức này?');">
                                                            <?= Csrf::field() ?>
                                                            <button type="submit" class="btn btn-xs btn-outline-danger py-1 px-2 rounded">
                                                                <i class="fa-solid fa-trash-can"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Modal Thêm Tri thức -->
<div class="modal fade" id="addKnowledgeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="<?= URL_ROOT ?>/admin/chatbot/add-knowledge" method="POST">
            <?= Csrf::field() ?>
            <div class="modal-content border-0 shadow">
                <div class="modal-header border-0 pb-0">
                    <h6 class="modal-title fw-bold">Thêm tài liệu tri thức (RAG Context)</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-start">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary mb-1">Phân loại danh mục</label>
                        <select name="category" class="form-select form-select-sm" required>
                            <option value="faq">Câu hỏi thường gặp (FAQ)</option>
                            <option value="prices">Bảng giá gói VIP & Nạp tiền</option>
                            <option value="policies">Chính sách & Pháp lý cọc nhà</option>
                            <option value="post_instructions">Hướng dẫn đăng ký/đăng tin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary mb-1">Tiêu đề tài liệu</label>
                        <input type="text" name="title" class="form-control form-control-sm" placeholder="Ví dụ: Quy chế tin thường..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary mb-1">Nội dung chi tiết (Tri thức dùng huấn luyện AI)</label>
                        <textarea name="content" rows="6" class="form-control form-control-sm" placeholder="Nhập tri thức mô tả chi tiết..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="submit" class="btn btn-sm btn-success w-100 fw-bold">Lưu tri thức</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal Sửa Tri thức -->
<div class="modal fade" id="editKnowledgeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form action="" method="POST" id="editKnowledgeForm">
            <?= Csrf::field() ?>
            <div class="modal-content border-0 shadow">
                <div class="modal-header border-0 pb-0">
                    <h6 class="modal-title fw-bold">Chỉnh sửa tài liệu tri thức</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-start">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary mb-1">Phân loại danh mục</label>
                        <select name="category" id="editKbCategory" class="form-select form-select-sm" required>
                            <option value="faq">Câu hỏi thường gặp (FAQ)</option>
                            <option value="prices">Bảng giá gói VIP & Nạp tiền</option>
                            <option value="policies">Chính sách & Pháp lý cọc nhà</option>
                            <option value="post_instructions">Hướng dẫn đăng ký/đăng tin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary mb-1">Tiêu đề tài liệu</label>
                        <input type="text" name="title" id="editKbTitle" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary mb-1">Nội dung chi tiết</label>
                        <textarea name="content" id="editKbContent" rows="6" class="form-control form-control-sm" required></textarea>
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="is_active" id="editKbActive" value="1">
                        <label class="form-check-label small fw-bold text-secondary" for="editKbActive">Kích hoạt sử dụng</label>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="submit" class="btn btn-sm btn-primary w-100 fw-bold">Lưu thay đổi</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function openEditKnowledgeModal(art) {
    document.getElementById('editKnowledgeForm').action = `<?= URL_ROOT ?>/admin/chatbot/update-knowledge/${art.id}`;
    document.getElementById('editKbCategory').value = art.category;
    document.getElementById('editKbTitle').value = art.title;
    document.getElementById('editKbContent').value = art.content;
    document.getElementById('editKbActive').checked = (parseInt(art.is_active) === 1);

    const modal = new bootstrap.Modal(document.getElementById('editKnowledgeModal'));
    modal.show();
}
</script>

<?php require_once '../app/views/admin/layouts/footer.php'; ?>
