<?php
/**
 * Component Hiển thị gợi ý câu hỏi nhanh cho người dùng đặt câu hỏi cho AI Chatbot.
 */
$suggestions = [
    'Làm thế nào để đăng ký tài khoản mới?',
    'Hướng dẫn các bước đăng tin bán nhà?',
    'Bảng giá gói VIP và cách nạp tiền?',
    'Tìm căn hộ dưới 3 tỷ ở Quận 7',
    'Chính sách mua bán giao dịch an toàn?'
];
?>

<div class="d-flex flex-wrap gap-2 mt-3 justify-content-center">
    <?php foreach ($suggestions as $s): ?>
        <button onclick="askSuggestion('<?= htmlspecialchars($s, ENT_QUOTES) ?>')" class="suggestion-tag">
            <i class="fa-solid fa-lightbulb text-warning me-1"></i> <?= htmlspecialchars($s) ?>
        </button>
    <?php endforeach; ?>
</div>
