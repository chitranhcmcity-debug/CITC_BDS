<?php
/**
 * Component Hiển thị bong bóng tin nhắn của Chatbot AI (Hỗ trợ Markdown cơ bản và Feedback).
 */
$isMine = $msg['role'] === 'user';
$time = isset($msg['created_at']) ? date('H:i', strtotime($msg['created_at'])) : '';

$text = $msg['message'];

if (!$isMine) {
    // Parser Markdown cơ bản cho AI
    // 1. Chữ in đậm **text**
    $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text);
    // 2. Link markdown [label](url)
    $text = preg_replace('/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" class="fw-bold text-success text-decoration-none">$1</a>', $text);
    // 3. Xuống dòng
    $text = nl2br($text);
} else {
    $text = htmlspecialchars($text);
}
?>

<div class="ai-msg-row <?= $isMine ? 'mine' : 'other' ?>" id="ai-msg-<?= $msg['id'] ?>">
    <?php if (!$isMine): ?>
        <div class="ai-avatar">
            <i class="fa-solid fa-robot"></i>
        </div>
    <?php endif; ?>

    <div class="ai-msg-bubble">
        <div class="ai-msg-text text-start" style="font-size: 0.92rem;">
            <?= $text ?>
        </div>
        
        <!-- Feedback nút bấm cho câu trả lời của AI -->
        <?php if (!$isMine && (int)$msg['id'] > 0): ?>
            <div class="ai-feedback-actions" id="feedback-actions-<?= $msg['id'] ?>">
                <button onclick="submitFeedback(<?= $msg['id'] ?>, 1)" class="ai-feedback-btn" title="Hữu ích">
                    <i class="fa-regular fa-thumbs-up"></i>
                </button>
                <button onclick="submitFeedback(<?= $msg['id'] ?>, -1)" class="ai-feedback-btn" title="Không hữu ích">
                    <i class="fa-regular fa-thumbs-down"></i>
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
