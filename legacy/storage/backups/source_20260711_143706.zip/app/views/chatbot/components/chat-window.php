<?php
/**
 * Component Khung hội thoại chính của Chatbot AI.
 */
?>
<div class="chatbot-container">
    <!-- Header hiển thị trạng thái AI -->
    <div class="chatbot-header d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center gap-3 text-start">
            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center text-success" style="width: 42px; height: 42px; font-size: 1.3rem; border: 1px solid #d1fae5;">
                <i class="fa-solid fa-robot"></i>
            </div>
            <div>
                <h5 class="fw-bold mb-0 text-dark" style="font-size: 0.95rem;">Trợ lý ảo AI TimNhaDat.site</h5>
                <span class="text-muted small" style="font-size: 0.72rem;">
                    <i class="fa-solid fa-circle text-success me-1"></i>Hỗ trợ tự động 24/7
                </span>
            </div>
        </div>

        <div>
            <button onclick="transferToHumanCSKH()" class="btn btn-sm btn-outline-primary rounded-pill fw-bold" style="font-size: 0.75rem;">
                <i class="fa-solid fa-headset me-1"></i> Gặp nhân viên CSKH
            </button>
        </div>
    </div>

    <!-- Khối logs tin nhắn -->
    <div class="chatbot-log-area flex-grow-1" id="chatbotMessageLog">
        <!-- Lời chào đầu tiên -->
        <div class="ai-msg-row other">
            <div class="ai-avatar"><i class="fa-solid fa-robot"></i></div>
            <div class="ai-msg-bubble">
                <div class="text-start">
                    Xin chào! Tôi là Trợ lý ảo AI của **TimNhaDat.site**. Tôi có thể giúp gì cho bạn hôm nay?<br><br>
                    💡 Bạn có thể hỏi tôi về:<br>
                    * Cách đăng tin bán/thuê nhà đất.<br>
                    * Bảng giá các dịch vụ VIP.<br>
                    * Tìm kiếm, gợi ý bất động sản thích hợp.<br>
                    * Hoặc các thủ tục pháp lý giao dịch cọc mua bán.
                </div>
            </div>
        </div>

        <!-- Render tin nhắn cũ từ CSDL nếu có -->
        <?php if (!empty($history)): ?>
            <?php foreach ($history as $msg): ?>
                <?php
                $msgArr = is_object($msg) ? get_object_vars($msg) : $msg;
                require '../app/views/chatbot/components/message.php';
                ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Hoạt ảnh gõ chữ (Typing Indicator) - Ẩn mặc định -->
    <div class="px-4 py-2 bg-light border-top d-none" id="aiTypingIndicator">
        <div class="ai-msg-row other mb-0">
            <div class="ai-avatar"><i class="fa-solid fa-robot"></i></div>
            <div class="typing-indicator">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
            </div>
        </div>
    </div>

    <!-- Footer nhập liệu -->
    <div class="chatbot-footer bg-white border-top p-3">
        <div class="d-flex gap-2">
            <input type="text" id="aiQueryInput" class="form-control rounded-pill border-1 px-4 py-2" style="font-size: 0.9rem;" placeholder="Nhập câu hỏi hoặc nhu cầu tìm nhà đất..." onkeydown="handleAiInputKey(event)">
            <button onclick="sendAiQuery()" class="btn btn-success rounded-circle d-flex align-items-center justify-content-center" style="width: 42px; height: 42px; flex-shrink: 0;">
                <i class="fa-solid fa-paper-plane" style="font-size: 0.95rem;"></i>
            </button>
        </div>
    </div>
</div>
