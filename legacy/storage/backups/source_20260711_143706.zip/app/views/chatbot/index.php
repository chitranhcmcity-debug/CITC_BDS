<?php require_once '../app/views/layouts/header.php'; ?>
<link rel="stylesheet" href="<?= URL_ROOT ?>/public/css/chatbot.css?v=<?= filemtime(APP_ROOT . '/public/css/chatbot.css') ?>">

<div class="container py-4">
    <div class="row">
        <!-- Sidebar thành viên -->
        <?php require '../app/views/nguoi-dung/sidebar.php'; ?>

        <!-- Nội dung chatbot -->
        <main class="col-lg-9 col-md-8 col-12">
            <!-- Khung chat chính -->
            <?php require '../app/views/chatbot/components/chat-window.php'; ?>

            <!-- Câu hỏi đề xuất nhanh bên dưới -->
            <?php require '../app/views/chatbot/components/suggestion.php'; ?>
        </main>
    </div>
</div>

<!-- SweetAlert2 để gửi góp ý -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const convId = <?= (int)$conv_id ?>;

// Cuộn xuống cuối khung tin nhắn khi bắt đầu
document.addEventListener("DOMContentLoaded", function() {
    scrollToBottom();
});

// Gửi câu hỏi cho AI Chatbot
function sendAiQuery() {
    const input = document.getElementById('aiQueryInput');
    const query = input.value.trim();
    if (!query) return;

    // Render câu hỏi của người dùng lên UI
    appendUserMessage(query);
    input.value = '';

    // Hiện hoạt ảnh gõ chữ (Typing indicator)
    const indicator = document.getElementById('aiTypingIndicator');
    indicator.classList.remove('d-none');
    scrollToBottom();

    // Gửi AJAX POST lên Controller
    const formData = new FormData();
    formData.append('message', query);

    fetch('<?= URL_ROOT ?>/api/chatbot/send', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        // Ẩn hoạt ảnh gõ chữ
        indicator.classList.add('d-none');

        if (data.success) {
            appendAiReply(data.message_id, data.reply);
        } else {
            appendSystemError(data.message || 'Lỗi không thể kết nối tới máy chủ AI.');
        }
        scrollToBottom();
    })
    .catch(err => {
        indicator.classList.add('d-none');
        appendSystemError('Lỗi kết nối mạng.');
        scrollToBottom();
    });
}

// Bấm câu hỏi gợi ý nhanh
function askSuggestion(text) {
    document.getElementById('aiQueryInput').value = text;
    sendAiQuery();
}

// Enter gửi câu hỏi
function handleAiInputKey(e) {
    if (e.key === 'Enter') {
        sendAiQuery();
    }
}

// Thêm tin nhắn của User lên UI
function appendUserMessage(text) {
    const log = document.getElementById('chatbotMessageLog');
    const row = document.createElement('div');
    row.className = 'ai-msg-row mine';
    row.innerHTML = `
        <div class="ai-msg-bubble">
            <div class="ai-msg-text text-start">${escapeHtml(text)}</div>
        </div>
    `;
    log.appendChild(row);
}

// Thêm tin nhắn phản hồi của AI lên UI
function appendAiReply(msgId, text) {
    const log = document.getElementById('chatbotMessageLog');
    const row = document.createElement('div');
    row.className = 'ai-msg-row other';
    row.id = `ai-msg-${msgId}`;

    // Parser Markdown đơn giản
    let htmlContent = text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" class="fw-bold text-success text-decoration-none">$1</a>')
        .replace(/\n/g, '<br>');

    row.innerHTML = `
        <div class="ai-avatar"><i class="fa-solid fa-robot"></i></div>
        <div class="ai-msg-bubble">
            <div class="ai-msg-text text-start">${htmlContent}</div>
            <div class="ai-feedback-actions" id="feedback-actions-${msgId}">
                <button onclick="submitFeedback(${msgId}, 1)" class="ai-feedback-btn" title="Hữu ích"><i class="fa-regular fa-thumbs-up"></i></button>
                <button onclick="submitFeedback(${msgId}, -1)" class="ai-feedback-btn" title="Không hữu ích"><i class="fa-regular fa-thumbs-down"></i></button>
            </div>
        </div>
    `;
    log.appendChild(row);
}

// Thêm tin nhắn lỗi hệ thống
function appendSystemError(text) {
    const log = document.getElementById('chatbotMessageLog');
    const row = document.createElement('div');
    row.className = 'text-center my-3 small text-danger';
    row.innerHTML = `<span><i class="fa-solid fa-circle-exclamation me-1"></i> ${escapeHtml(text)}</span>`;
    log.appendChild(row);
}

// Gửi đánh giá Thumbs Up/Down
function submitFeedback(msgId, rating) {
    if (rating === -1) {
        // Nếu không hữu ích, hiện hộp thoại điền ý kiến đóng góp
        Swal.fire({
            title: 'Góp ý để AI thông minh hơn',
            input: 'textarea',
            inputPlaceholder: 'Hãy cho chúng tôi biết tại sao câu trả lời này chưa tốt...',
            showCancelButton: true,
            confirmButtonText: 'Gửi góp ý',
            cancelButtonText: 'Hủy',
            confirmButtonColor: '#10b981'
        }).then((result) => {
            if (result.isConfirmed) {
                sendFeedbackAjax(msgId, rating, result.value);
            }
        });
    } else {
        sendFeedbackAjax(msgId, rating, '');
    }
}

function sendFeedbackAjax(msgId, rating, text) {
    const formData = new FormData();
    formData.append('conversation_id', convId);
    formData.append('message_id', msgId);
    formData.append('rating', rating);
    formData.append('feedback_text', text);

    fetch('<?= URL_ROOT ?>/api/chatbot/feedback', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Ẩn nút feedback
            const container = document.getElementById(`feedback-actions-${msgId}`);
            if (container) {
                container.innerHTML = `<span class="text-success small"><i class="fa-solid fa-check me-1"></i> Cảm ơn bạn đã đánh giá!</span>`;
            }
        }
    })
    .catch(err => console.error(err));
}

// Cắt chuyển sang Live Chat gặp CSKH nhân viên
function transferToHumanCSKH() {
    if (!confirm('Bạn có muốn chuyển phiên trò chuyện này sang nhân viên chăm sóc khách hàng trực tiếp?')) return;

    const formData = new FormData();
    formData.append('conversation_id', convId);

    fetch('<?= URL_ROOT ?>/api/chatbot/transfer', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                title: 'Đã chuyển CSKH!',
                text: 'Hệ thống đang chuyển bạn sang Live Chat với nhân viên hỗ trợ.',
                icon: 'success',
                confirmButtonColor: '#0ea5e9'
            }).then(() => {
                window.location.href = '<?= URL_ROOT ?>/chat';
            });
        }
    })
    .catch(err => console.error(err));
}

function escapeHtml(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function scrollToBottom() {
    const log = document.getElementById('chatbotMessageLog');
    log.scrollTop = log.scrollHeight;
}
</script>
<?php require_once '../app/views/layouts/footer.php'; ?>
