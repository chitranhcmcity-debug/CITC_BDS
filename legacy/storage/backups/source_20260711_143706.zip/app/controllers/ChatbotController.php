<?php
/**
 * ChatbotController – Quản lý phiên hội thoại và tương tác của AI Chatbot với Người dùng.
 * Hỗ trợ lưu trữ hỏi đáp, đánh giá AI, đề xuất câu hỏi nhanh và cắt chuyển sang CSKH.
 */
class ChatbotController extends Controller
{
    private ChatbotService $service;

    public function __construct()
    {
        require_once APP_ROOT . '/app/services/ChatbotService.php';
        $this->service = new ChatbotService();
    }

    /**
     * Giao diện Chatbot AI 24/7.
     * URL: GET /chatbot
     */
    public function index(): void
    {
        $userId = Session::get('user_id') ? (int)Session::get('user_id') : null;
        $sessionId = $this->getSessionId();

        $convId = $this->service->getConvRepo()->getOrCreate($sessionId, $userId);
        $history = $this->service->getConvRepo()->getMessages($convId);

        $this->view('chatbot/index', [
            'title'   => 'Trợ lý ảo AI Bất động sản 24/7 - ' . SITE_NAME,
            'conv_id' => $convId,
            'history' => $history
        ]);
    }

    /**
     * Gửi câu hỏi đến Chatbot AI.
     * URL: POST /chatbot/send
     */
    public function send(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Method not allowed.'], 405);
            return;
        }

        // Đảm bảo có bảo vệ Rate limit chống Spam
        $rateKey = 'chatbot_ai|' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        if ($this->isRateLimited($rateKey)) {
            $this->json(['success' => false, 'message' => 'Bạn gửi yêu cầu quá nhanh. Vui lòng thử lại sau.'], 429);
            return;
        }

        $message = trim($_POST['message'] ?? '');
        if ($message === '') {
            $this->json(['success' => false, 'message' => 'Nội dung câu hỏi không được để trống.'], 422);
            return;
        }

        $userId = Session::get('user_id') ? (int)Session::get('user_id') : null;
        $sessionId = $this->getSessionId();

        $convId = $this->service->getConvRepo()->getOrCreate($sessionId, $userId);
        if ($convId <= 0) {
            $this->json(['success' => false, 'message' => 'Không thể tạo phiên hội thoại.'], 500);
            return;
        }

        // Tương tác hỏi đáp AI
        $res = $this->service->ask($convId, $message);

        $this->json([
            'success'    => true,
            'message_id' => $res['message_id'],
            'reply'      => $res['reply'],
            'suggested'  => $res['suggested']
        ]);
    }

    /**
     * Tải lịch sử tin nhắn trò chuyện của phiên hiện tại.
     * URL: GET /chatbot/history
     */
    public function history(): void
    {
        $userId = Session::get('user_id') ? (int)Session::get('user_id') : null;
        $sessionId = $this->getSessionId();

        $convId = $this->service->getConvRepo()->getOrCreate($sessionId, $userId);
        $messages = $this->service->getConvRepo()->getMessages($convId);

        $this->json([
            'success'  => true,
            'messages' => $messages
        ]);
    }

    /**
     * Đánh giá chất lượng của câu trả lời AI (Thumbs Up/Down).
     * URL: POST /chatbot/feedback
     */
    public function feedback(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Method not allowed.'], 405);
            return;
        }

        $convId = (int)($_POST['conversation_id'] ?? 0);
        $msgId = (int)($_POST['message_id'] ?? 0);
        $rating = (int)($_POST['rating'] ?? 1); // 1: helpful, -1: unhelpful
        $feedbackText = trim($_POST['feedback_text'] ?? '');

        if ($convId <= 0 || $msgId <= 0 || !in_array($rating, [1, -1], true)) {
            $this->json(['success' => false, 'message' => 'Thông tin đánh giá không hợp lệ.'], 400);
            return;
        }

        $feedbackId = $this->service->saveFeedback($convId, $msgId, $rating, $feedbackText);
        if ($feedbackId > 0) {
            $this->json(['success' => true, 'message' => 'Cảm ơn góp ý của bạn để AI thông minh hơn!']);
        } else {
            $this->json(['success' => false, 'message' => 'Lỗi lưu phản hồi.'], 500);
        }
    }

    /**
     * Cắt chuyển sang Live Chat CSKH khi AI không hỗ trợ được.
     * URL: POST /chatbot/transfer-human
     */
    public function transfer(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Method not allowed.'], 405);
            return;
        }

        $convId = (int)($_POST['conversation_id'] ?? 0);
        if ($convId <= 0) {
            $this->json(['success' => false, 'message' => 'Không tìm thấy cuộc hội thoại.'], 400);
            return;
        }

        // Cập nhật trạng thái cuộc hội thoại AI sang 'transferred'
        $this->service->getConvRepo()->updateStatus($convId, 'transferred');

        // Tạo cuộc trò chuyện Live Chat CSKH thực tế (nạp session)
        $userId = Session::get('user_id') ? (int)Session::get('user_id') : null;
        $guestToken = Session::get('chat_guest_id') ?: null;
        if (!$guestToken && !$userId) {
            Session::set('chat_guest_id', bin2hex(random_bytes(24)));
            $guestToken = Session::get('chat_guest_id');
        }

        require_once APP_ROOT . '/app/services/ConversationService.php';
        $liveChatConvSvc = new ConversationService();
        
        $liveChatId = $liveChatConvSvc->getOrCreate('customer_cskh', $userId, $guestToken);

        // Tạo tin nhắn tự động thông báo CSKH
        require_once APP_ROOT . '/app/services/ChatService.php';
        $chatSvc = new ChatService();
        $chatSvc->sendMessage(
            $liveChatId, 
            null, 
            'Hệ thống', 
            'Khách hàng yêu cầu chuyển giao từ Chatbot AI sang tư vấn CSKH trực tiếp.', 
            'system'
        );

        $this->json([
            'success'      => true,
            'live_chat_id' => $liveChatId,
            'message'      => 'Đã kết nối với nhân viên CSKH.'
        ]);
    }

    private function getSessionId(): string
    {
        if (!Session::get('chatbot_session_id')) {
            Session::set('chatbot_session_id', 'session_ai_' . bin2hex(random_bytes(16)));
        }
        return Session::get('chatbot_session_id');
    }

    private function isRateLimited(string $key): bool
    {
        // Chống spam: tối đa 30 câu hỏi / 1 phút
        $limit = 30;
        $period = 60;

        $file = sys_get_temp_dir() . '/bds_limit_' . md5($key) . '.json';
        $data = ['count' => 0, 'expires_at' => time() + $period];

        if (file_exists($file)) {
            $raw = @file_get_contents($file);
            $data = json_decode($raw, true) ?: $data;
        }

        if (time() > $data['expires_at']) {
            $data['count'] = 1;
            $data['expires_at'] = time() + $period;
        } else {
            $data['count']++;
        }

        @file_put_contents($file, json_encode($data));

        return $data['count'] > $limit;
    }

    private function json(array $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
