<?php
/**
 * AdminChatbotController – Quản lý Cơ sở tri thức (Knowledge Base), cấu hình Prompt 
 * và phân tích số liệu thống kê mức độ hài lòng của AI Chatbot.
 * Quyền truy cập: Quản trị viên (Role ID = 1).
 */
class AdminChatbotController extends Controller
{
    private ChatbotService $service;
    private KnowledgeService $knowledgeSvc;
    private PromptService $promptSvc;

    public function __construct()
    {
        require_once APP_ROOT . '/app/services/ChatbotService.php';
        require_once APP_ROOT . '/app/services/KnowledgeService.php';
        require_once APP_ROOT . '/app/services/PromptService.php';

        $this->service = new ChatbotService();
        $this->knowledgeSvc = new KnowledgeService();
        $this->promptSvc = new PromptService();
    }

    /**
     * Bảng điều khiển quản trị Chatbot AI.
     * URL: GET /admin/chatbot
     */
    public function index(): void
    {
        $this->requireAdmin();

        $stats = $this->service->getAnalytics();
        $articles = $this->knowledgeSvc->listArticles();
        $promptContent = $this->promptSvc->getInstruction();
        $feedbacks = $this->service->getFeedbackRepo()->listAll();

        $this->view('admin/chatbot', [
            'title'         => 'Cấu hình Trợ lý ảo AI - ' . SITE_NAME,
            'stats'         => $stats,
            'articles'      => $articles,
            'promptContent' => $promptContent,
            'feedbacks'     => $feedbacks
        ]);
    }

    /**
     * Cập nhật câu lệnh chỉ dẫn hệ thống Prompt.
     * URL: POST /admin/chatbot/save-prompt
     */
    public function savePrompt(): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('admin/chatbot');
        }

        if (!Csrf::verify()) {
            $_SESSION['flash_error'] = 'Yêu cầu bảo mật không hợp lệ.';
            $this->redirect('admin/chatbot');
        }

        $promptContent = trim($_POST['content'] ?? '');
        if (empty($promptContent)) {
            $_SESSION['flash_error'] = 'Nội dung Prompt không được để trống.';
            $this->redirect('admin/chatbot');
        }

        if ($this->promptSvc->saveInstruction($promptContent)) {
            $_SESSION['flash_success'] = 'Cấu hình Prompt hệ thống thành công.';
        } else {
            $_SESSION['flash_error'] = 'Không thể lưu cấu hình Prompt.';
        }

        $this->redirect('admin/chatbot');
    }

    /**
     * Thêm tài liệu tri thức mới (Knowledge Base).
     * URL: POST /admin/chatbot/add-knowledge
     */
    public function addKnowledge(): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('admin/chatbot');
        }

        if (!Csrf::verify()) {
            $_SESSION['flash_error'] = 'Yêu cầu bảo mật không hợp lệ.';
            $this->redirect('admin/chatbot');
        }

        $category = trim($_POST['category'] ?? 'faq');
        $title    = trim($_POST['title'] ?? '');
        $content  = trim($_POST['content'] ?? '');

        if (empty($title) || empty($content)) {
            $_SESSION['flash_error'] = 'Tiêu đề và nội dung tri thức không được để trống.';
            $this->redirect('admin/chatbot');
        }

        $data = [
            'category'  => $category,
            'title'     => $title,
            'content'   => $content,
            'is_active' => 1
        ];

        if ($this->knowledgeSvc->addArticle($data) > 0) {
            $_SESSION['flash_success'] = 'Thêm tài liệu tri thức thành công.';
        } else {
            $_SESSION['flash_error'] = 'Không thể lưu tài liệu.';
        }

        $this->redirect('admin/chatbot');
    }

    /**
     * Cập nhật tài liệu tri thức.
     * URL: POST /admin/chatbot/update-knowledge/{id}
     */
    public function updateKnowledge(?string $id = null): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('admin/chatbot');
        }

        if (!Csrf::verify()) {
            $_SESSION['flash_error'] = 'Yêu cầu bảo mật không hợp lệ.';
            $this->redirect('admin/chatbot');
        }

        $artId = (int)$id;
        $category = trim($_POST['category'] ?? 'faq');
        $title    = trim($_POST['title'] ?? '');
        $content  = trim($_POST['content'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        $data = [
            'category'  => $category,
            'title'     => $title,
            'content'   => $content,
            'is_active' => $isActive
        ];

        if ($this->knowledgeSvc->updateArticle($artId, $data)) {
            $_SESSION['flash_success'] = 'Cập nhật tài liệu thành công.';
        } else {
            $_SESSION['flash_error'] = 'Lỗi cập nhật tài liệu.';
        }

        $this->redirect('admin/chatbot');
    }

    /**
     * Xóa tài liệu tri thức.
     * URL: POST /admin/chatbot/delete-knowledge/{id}
     */
    public function deleteKnowledge(?string $id = null): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('admin/chatbot');
        }

        if (!Csrf::verify()) {
            $_SESSION['flash_error'] = 'Yêu cầu bảo mật không hợp lệ.';
            $this->redirect('admin/chatbot');
        }

        $artId = (int)$id;

        // Lấy dữ liệu tài liệu trước khi xóa để ghi log
        $articles = $this->knowledgeSvc->listArticles();
        $articleData = [];
        foreach ($articles as $art) {
            if ((int)($art->id ?? $art['id'] ?? 0) === $artId) {
                $articleData = (array)$art;
                break;
            }
        }

        if ($this->knowledgeSvc->deleteArticle($artId)) {
            // Ghi log admin
            SystemLogger::admin(
                'delete',
                'chatbot',
                'knowledge_base',
                $artId,
                "Xóa tài liệu tri thức: #{$artId}" . (!empty($articleData['title']) ? " - {$articleData['title']}" : ''),
                $articleData,
                [],
                (int)Session::get('user_id')
            );

            $_SESSION['flash_success'] = 'Đã xóa tài liệu tri thức.';
        } else {
            $_SESSION['flash_error'] = 'Lỗi xóa tài liệu.';
        }

        $this->redirect('admin/chatbot');
    }

    private function requireAdmin(): void
    {
        if ((int)Session::get('user_id') <= 0 || (int)Session::get('user_role_id') !== 1) {
            $this->redirect('nguoi-dung/dang-nhap');
            exit;
        }
    }
}
