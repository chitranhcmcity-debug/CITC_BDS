<?php
/**
 * ChatService – Quản lý gửi tin nhắn, tích hợp AI Chatbot và đồng bộ hoá Realtime.
 * Tuân thủ SOLID, Service Pattern.
 */
class ChatService
{
    private MessageRepository $messageRepo;
    private ConversationRepository $convRepo;
    private AttachmentRepository $attachRepo;

    public function __construct()
    {
        require_once APP_ROOT . '/app/repositories/MessageRepository.php';
        require_once APP_ROOT . '/app/repositories/ConversationRepository.php';
        require_once APP_ROOT . '/app/repositories/AttachmentRepository.php';

        $this->messageRepo = new MessageRepository();
        $this->convRepo = new ConversationRepository();
        $this->attachRepo = new AttachmentRepository();
    }

    public function getMessageRepo(): MessageRepository
    {
        return $this->messageRepo;
    }

    public function getAttachRepo(): AttachmentRepository
    {
        return $this->attachRepo;
    }

    /**
     * Gửi tin nhắn mới trong hội thoại.
     */
    public function sendMessage(int $conversationId, ?int $senderId, string $senderName, string $message, string $messageType = 'text', ?string $attachment = null): int|false
    {
        $conv = $this->convRepo->findById($conversationId);
        if (!$conv) return false;

        $msgData = [
            'conversation_id' => $conversationId,
            'sender_id'       => $senderId,
            'sender_name'     => $senderName,
            'message'         => trim($message),
            'message_type'    => $messageType,
            'attachment'      => $attachment,
            'is_read'         => 0
        ];

        $insertedId = $this->messageRepo->insert($msgData);
        if ($insertedId <= 0) return false;

        $msgData['id'] = $insertedId;
        $msgData['created_at'] = date('Y-m-d H:i:s');

        // Cập nhật thời gian tương tác cuối trên hội thoại
        $db = new Database();
        $db->query("UPDATE chat_conversations SET updated_at = NOW() WHERE id = :id");
        $db->bind(':id', $conversationId);
        $db->execute();

        // ── ĐẨY REALTIME QUA SSE ──
        $this->dispatchRealtime($conv, $msgData);

        // ── AI CHATBOT TỰ ĐỘNG PHẢN HỒI ──
        if ($conv->type === 'customer_chatbot' && $senderId !== null && $senderId !== 0 && $senderName !== 'AI Chatbot') {
            $this->triggerChatbotResponse($conversationId, $message);
        }

        return $insertedId;
    }

    /**
     * Phân phối tin nhắn realtime tới các bên liên quan.
     */
    private function dispatchRealtime(object $conv, array $msg): void
    {
        $userIdsToNotify = [];
        $guestTokensToNotify = [];

        // Xác định ai sẽ nhận tin nhắn này (loại trừ người gửi)
        $senderId = $msg['sender_id'];

        if ($conv->type === 'customer_seller') {
            if ($senderId === $conv->customer_id) {
                if ($conv->seller_id) $userIdsToNotify[] = $conv->seller_id;
            } else {
                if ($conv->customer_id) $userIdsToNotify[] = $conv->customer_id;
                if ($conv->customer_guest_token) $guestTokensToNotify[] = $conv->customer_guest_token;
            }
        } elseif ($conv->type === 'customer_cskh') {
            if ($senderId === $conv->customer_id) {
                // Đẩy cho nhân viên hỗ trợ được gán, hoặc toàn bộ admin/staff nếu chưa gán
                if ($conv->staff_id) {
                    $userIdsToNotify[] = $conv->staff_id;
                } else {
                    // Lấy toàn bộ Admin/CSKH
                    $userRepo = new UserRepository();
                    $admins = $userRepo->findByRole(1); // Admin
                    foreach ($admins as $ad) {
                        $userIdsToNotify[] = (int)$ad->id;
                    }
                }
            } else {
                if ($conv->customer_id) $userIdsToNotify[] = $conv->customer_id;
                if ($conv->customer_guest_token) $guestTokensToNotify[] = $conv->customer_guest_token;
            }
        } elseif ($conv->type === 'cskh_admin') {
            if ($senderId === $conv->staff_id) {
                $userIdsToNotify[] = $conv->customer_id; // Chứa admin ID ở đầu kia
            } else {
                $userIdsToNotify[] = $conv->staff_id;
            }
        }

        // Ghi vào file buffer SSE
        foreach ($userIdsToNotify as $uid) {
            $this->publishSseUser($uid, $msg);
        }
        foreach ($guestTokensToNotify as $token) {
            $this->publishSseGuest($token, $msg);
        }
    }

    private function publishSseUser(int $userId, array $msg): void
    {
        $file = sys_get_temp_dir() . '/chat_sse_user_' . $userId . '.json';
        $events = [];
        if (file_exists($file)) {
            $raw = @file_get_contents($file);
            $events = json_decode($raw, true) ?: [];
        }
        $events[] = $msg;
        @file_put_contents($file, json_encode($events, JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    private function publishSseGuest(string $token, array $msg): void
    {
        $file = sys_get_temp_dir() . '/chat_sse_guest_' . md5($token) . '.json';
        $events = [];
        if (file_exists($file)) {
            $raw = @file_get_contents($file);
            $events = json_decode($raw, true) ?: [];
        }
        $events[] = $msg;
        @file_put_contents($file, json_encode($events, JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    /**
     * Kích hoạt AI Chatbot phản hồi.
     */
    private function triggerChatbotResponse(int $conversationId, string $userMessage): void
    {
        $apiKey = (string)(env('GEMINI_API_KEY', '') ?: CaiDat::get('gemini_api_key'));
        
        $reply = "";
        if (!empty($apiKey)) {
            // Gọi Gemini API
            $reply = $this->callGemini($apiKey, $userMessage);
        }

        // Fallback chuyên nghiệp nếu API lỗi hoặc chưa cấu hình
        if (empty($reply)) {
            $reply = $this->getRuleBasedReply($userMessage);
        }

        // Lưu câu trả lời của AI vào hội thoại
        $msgData = [
            'conversation_id' => $conversationId,
            'sender_id'       => 0, // 0 đại diện cho AI Chatbot
            'sender_name'     => 'AI Chatbot',
            'message'         => $reply,
            'message_type'    => 'text',
            'attachment'      => null,
            'is_read'         => 0
        ];
        
        $this->messageRepo->insert($msgData);
        $msgData['id'] = 0;
        $msgData['created_at'] = date('Y-m-d H:i:s');
        
        // Đẩy realtime câu trả lời của AI về cho khách hàng
        $conv = $this->convRepo->findById($conversationId);
        if ($conv) {
            $this->dispatchRealtime($conv, $msgData);
        }
    }

    private function callGemini(string $apiKey, string $message): string
    {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $apiKey;
        $system = "Bạn là trợ lý ảo AI của TimNhaDat.site. Hãy hỗ trợ tư vấn bất động sản, dự án và cách đăng tin một cách ngắn gọn, súc tích dưới 150 từ.";
        
        $payload = [
            'contents' => [
                ['parts' => [['text' => $message]]]
            ],
            'systemInstruction' => [
                'parts' => [['text' => $system]]
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 6);
        
        $response = curl_exec($ch);
        curl_close($ch);

        if ($response) {
            $data = json_decode($response, true);
            return $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        }
        return '';
    }

    private function getRuleBasedReply(string $msg): string
    {
        $msg = mb_strtolower($msg, 'UTF-8');
        
        if (str_contains($msg, 'giá') || str_contains($msg, 'bao nhiêu')) {
            return "Chào bạn, giá cả bất động sản dao động tùy thuộc vào vị trí, diện tích và dự án cụ thể. Bạn vui lòng để lại số điện thoại hoặc liên hệ hotline " . CaiDat::get('hotline') . " để chúng tôi báo giá chính xác nhất nhé!";
        }
        if (str_contains($msg, 'dự án') || str_contains($msg, 'chung cư')) {
            return "TimNhaDat.site có rất nhiều dự án căn hộ, shophouse và đất nền hot với vị trí đắc địa và sinh lời cao. Bạn quan tâm khu vực nào (Quận 1, Quận 7, v.v.) để mình hỗ trợ nhé?";
        }
        if (str_contains($msg, 'đăng tin') || str_contains($msg, 'bán nhà')) {
            return "Để đăng tin bán hoặc cho thuê nhà đất, bạn chỉ cần Đăng ký tài khoản thành viên, nhấn nút **Đăng tin** ở góc phải màn hình, điền thông tin và hình ảnh là xong. Tin đăng của bạn sẽ tiếp cận hàng triệu khách hàng!";
        }
        return "Xin chào! Cảm ơn bạn đã nhắn tin cho TimNhaDat.site. Hiện tại tư vấn viên đang bận, trợ lý AI xin ghi nhận thông tin của bạn. Vui lòng để lại số điện thoại hoặc gọi Hotline: " . CaiDat::get('hotline') . " để nhận phản hồi nhanh nhất!";
    }
}
