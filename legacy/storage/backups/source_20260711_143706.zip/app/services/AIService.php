<?php
/**
 * AIService – Tương tác trực tiếp với API Google Gemini để sinh phản hồi thông minh.
 * Tuân thủ SOLID, Service Pattern.
 */
class AIService
{
    private PromptService $promptSvc;
    private KnowledgeService $knowledgeSvc;

    public function __construct()
    {
        require_once APP_ROOT . '/app/services/PromptService.php';
        require_once APP_ROOT . '/app/services/KnowledgeService.php';

        $this->promptSvc = new PromptService();
        $this->knowledgeSvc = new KnowledgeService();
    }

    /**
     * Gọi Gemini API nhận câu trả lời dựa trên Prompt hệ thống + Tri thức + Lịch sử.
     */
    public function generateReply(string $userMessage, array $chatHistory = []): string
    {
        $apiKey = (string)(env('GEMINI_API_KEY', '') ?: CaiDat::get('gemini_api_key'));
        $model = CaiDat::get('gemini_model') ?: 'gemini-2.5-flash';

        // 1. Nhận Prompt hệ thống & Tri thức nền tảng
        $systemInstruction = $this->promptSvc->getInstruction();
        $knowledgeContext = $this->knowledgeSvc->getKnowledgeContext();
        
        $fullInstruction = $systemInstruction . "\n" . $knowledgeContext;

        // 2. Chuyển đổi lịch sử chat phù hợp định dạng Gemini
        $contents = [];
        foreach ($chatHistory as $msg) {
            $role = ($msg->role === 'user') ? 'user' : 'model';
            $contents[] = [
                'role' => $role,
                'parts' => [['text' => mb_substr((string)$msg->message, 0, 2000)]]
            ];
        }

        // Thêm câu hỏi hiện tại
        $contents[] = [
            'role' => 'user',
            'parts' => [['text' => $userMessage]]
        ];

        // Gửi API
        $reply = "";
        if (!empty($apiKey)) {
            $reply = $this->callGeminiApi($apiKey, $model, $fullInstruction, $contents);
        }

        // Fallback rule-based nếu API rỗng/lỗi
        if (empty($reply)) {
            $reply = $this->getFallbackResponse($userMessage);
        }

        return $reply;
    }

    private function callGeminiApi(string $apiKey, string $model, string $system, array $contents): string
    {
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";
        
        $postData = [
            'contents' => $contents,
            'systemInstruction' => [
                'parts' => [['text' => $system]]
            ],
            'generationConfig' => [
                'temperature' => 0.7,
                'maxOutputTokens' => 1500
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        
        // Tắt verification trên localhost
        $isLocal = str_contains(URL_ROOT, 'localhost') || str_contains(URL_ROOT, '127.0.0.1');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, !$isLocal);

        $res = curl_exec($ch);
        curl_close($ch);

        if ($res) {
            $data = json_decode($res, true);
            return $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        }
        return '';
    }

    private function getFallbackResponse(string $msg): string
    {
        $msg = mb_strtolower($msg, 'UTF-8');
        
        if (str_contains($msg, 'đăng ký')) {
            return "Để đăng ký tài khoản:\n1. Bấm nút **Đăng ký** ở góc trên cùng bên phải trang chủ.\n2. Nhập thông tin và kích hoạt mã OTP email.";
        }
        if (str_contains($msg, 'đăng tin')) {
            return "Để đăng tin:\n1. Đăng nhập tài khoản thành viên.\n2. Nhấp nút **Đăng tin** ở thanh điều hướng.\n3. Điền thông tin mô tả, chọn gói tin và lưu lại.";
        }
        if (str_contains($msg, 'nạp tiền')) {
            return "Bạn có thể nạp tiền vào Ví điện tử TimNhaDat.site bằng cách chuyển khoản qua cổng QR ngân hàng hoặc MoMo tại trang quản lý Cá nhân.";
        }
        return "Xin chào! Cảm ơn bạn đã nhắn tin. Rất tiếc hệ thống AI đang quá tải, bạn có thể bấm nút **Gặp nhân viên CSKH** bên dưới hoặc gọi hotline: **" . CaiDat::get('hotline') . "** để được phục vụ trực tiếp ngay nhé!";
    }
}
