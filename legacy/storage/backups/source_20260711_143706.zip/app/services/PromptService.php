<?php
/**
 * PromptService – Quản lý cấu hình Prompt hệ thống (System Instruction).
 * Tuân thủ SOLID, Service Pattern.
 */
class PromptService
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    /**
     * Nhận câu lệnh chỉ dẫn hệ thống của AI.
     */
    public function getInstruction(): string
    {
        $this->db->query("SELECT content FROM chatbot_prompts WHERE name = 'system_instruction' AND is_active = 1 LIMIT 1");
        $row = $this->db->single();
        return $row ? $row->content : "Bạn là trợ lý ảo AI của sàn giao dịch TimNhaDat.site.";
    }

    /**
     * Cập nhật câu lệnh chỉ dẫn hệ thống.
     */
    public function saveInstruction(string $content): bool
    {
        $this->db->query("UPDATE chatbot_prompts SET content = :content WHERE name = 'system_instruction'");
        $this->db->bind(':content', trim($content));
        return $this->db->execute();
    }
}
