<?php
/**
 * RecommendationService – Phân tích nhu cầu trong tin nhắn để gợi ý 5 bất động sản thực tế.
 * Tuân thủ SOLID, Service Pattern.
 */
class RecommendationService
{
    private PropertyRepository $repo;

    public function __construct()
    {
        require_once APP_ROOT . '/app/repositories/PropertyRepository.php';
        $this->repo = new PropertyRepository();
    }

    /**
     * Phân tích nội dung và đưa ra đề xuất.
     */
    public function getRecommendations(string $userQuery): array
    {
        $parsed = $this->parseQuery($userQuery);
        return $this->repo->findRecommendations(
            $parsed['budget'],
            $parsed['location'],
            $parsed['area'],
            $parsed['type'],
            $parsed['purpose']
        );
    }

    /**
     * Bộ phân tích thô sơ dựa trên quy luật từ khóa (Rule-based parsing).
     */
    private function parseQuery(string $query): array
    {
        $queryLower = mb_strtolower($query, 'UTF-8');

        $budget = null;
        $location = null;
        $area = null;
        $type = null;
        $purpose = 'ban'; // Mặc định là bán

        // 1. Phân tích mục đích giao dịch
        if (str_contains($queryLower, 'thuê') || str_contains($queryLower, 'cho thuê')) {
            $purpose = 'thue';
        }

        // 2. Phân tích loại bất động sản
        if (str_contains($queryLower, 'căn hộ') || str_contains($queryLower, 'chung cư')) {
            $type = 'Căn hộ';
        } elseif (str_contains($queryLower, 'nhà riêng') || str_contains($queryLower, 'nhà phố') || str_contains($queryLower, 'nhà hẻm')) {
            $type = 'Nhà riêng';
        } elseif (str_contains($queryLower, 'đất nền') || str_contains($queryLower, 'đất')) {
            $type = 'Đất nền';
        } elseif (str_contains($queryLower, 'shophouse') || str_contains($queryLower, 'cửa hàng')) {
            $type = 'Shophouse';
        }

        // 3. Phân tích vị trí (Tìm các Quận/Huyện phổ biến)
        $districts = ['quận 1', 'quận 2', 'quận 3', 'quận 7', 'bình thạnh', 'thủ đức', 'gò vấp', 'tân bình', 'hà nội', 'hồ chí minh'];
        foreach ($districts as $d) {
            if (str_contains($queryLower, $d)) {
                $location = ucwords($d);
                break;
            }
        }

        // 4. Phân tích ngân sách (Ví dụ: "dưới 2 tỷ", "3 tỷ", "15 triệu")
        if (preg_match('/(\d+)\s*(tỷ|triệu|tr)/u', $queryLower, $matches)) {
            $value = (float)$matches[1];
            $unit = $matches[2];
            
            if ($unit === 'tỷ') {
                $budget = $value * 1000000000;
            } else {
                $budget = $value * 1000000;
            }
        }

        // 5. Phân tích diện tích (Ví dụ: "trên 50m2", "80 m2")
        if (preg_match('/(\d+)\s*(m2|mét vuông|met vuong)/u', $queryLower, $matches)) {
            $area = (float)$matches[1];
        }

        return [
            'budget'   => $budget,
            'location' => $location,
            'area'     => $area,
            'type'     => $type,
            'purpose'  => $purpose
        ];
    }
}
