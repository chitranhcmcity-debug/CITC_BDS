<?php
/**
 * ChatbotService – Dịch vụ điều phối chính của phân hệ Chatbot AI.
 * Kết hợp tri thức, AI sinh ý kiến và đề xuất dự án.
 * Tuân thủ SOLID, Service Pattern.
 */
class ChatbotService
{
    private ChatbotConversationRepository $convRepo;
    private FeedbackRepository $feedbackRepo;
    private AIService $aiSvc;
    private RecommendationService $recomSvc;

    public function __construct()
    {
        require_once APP_ROOT . '/app/repositories/ChatbotConversationRepository.php';
        require_once APP_ROOT . '/app/repositories/FeedbackRepository.php';
        require_once APP_ROOT . '/app/services/AIService.php';
        require_once APP_ROOT . '/app/services/RecommendationService.php';

        $this->convRepo = new ChatbotConversationRepository();
        $this->feedbackRepo = new FeedbackRepository();
        $this->aiSvc = new AIService();
        $this->recomSvc = new RecommendationService();
    }

    public function getConvRepo(): ChatbotConversationRepository
    {
        return $this->convRepo;
    }

    public function getFeedbackRepo(): FeedbackRepository
    {
        return $this->feedbackRepo;
    }

    /**
     * Tiếp nhận câu hỏi, sinh câu trả lời và tự động tìm kiếm bất động sản gợi ý.
     */
    public function ask(int $conversationId, string $message): array
    {
        // 1. Lưu tin nhắn của người dùng
        $this->convRepo->addMessage($conversationId, 'user', $message);

        // 2. Lấy lịch sử chat để làm ngữ cảnh ghi nhớ (nhận 10 tin nhắn gần nhất)
        $history = $this->convRepo->getMessages($conversationId);
        $contextHistory = array_slice($history, -10);

        // 3. Sinh câu trả lời của AI
        $aiReply = $this->aiSvc->generateReply($message, $contextHistory);

        // 4. Tìm kiếm đề xuất bất động sản
        $properties = $this->recomSvc->getRecommendations($message);
        $sourcesArr = [];

        if (!empty($properties)) {
            $aiReply .= "\n\n🏠 **Dưới đây là gợi ý 5 bất động sản phù hợp nhất trên sàn TimNhaDat.site:**\n";
            foreach ($properties as $idx => $p) {
                $gia = $p->gia;
                if (is_numeric($gia)) {
                    if ($gia >= 1000000000) $gia = ($gia / 1000000000) . ' tỷ';
                    elseif ($gia >= 1000000) $gia = ($gia / 1000000) . ' triệu';
                    else $gia = number_format($gia) . ' đ';
                }
                $url = URL_ROOT . '/du-an/detail/' . $p->duong_dan;
                $aiReply .= ($idx + 1) . ". **{$p->tieu_de}** - Giá: **{$gia}** - DT: **{$p->dien_tich}m²** tại *{$p->vi_tri}*\n";
                $aiReply .= "   👉 [Xem chi tiết tin đăng tại đây]({$url})\n";
                
                $sourcesArr[] = [
                    'id' => $p->id,
                    'title' => $p->tieu_de,
                    'url' => $url
                ];
            }
        }

        // 5. Lưu câu trả lời của AI vào CSDL
        $sourcesJson = !empty($sourcesArr) ? json_encode($sourcesArr, JSON_UNESCAPED_UNICODE) : null;
        $msgId = $this->convRepo->addMessage($conversationId, 'model', $aiReply, $sourcesJson);

        return [
            'message_id' => $msgId,
            'reply'      => $aiReply,
            'suggested'  => !empty($properties)
        ];
    }

    /**
     * Lưu đánh giá hữu ích / không hữu ích.
     */
    public function saveFeedback(int $conversationId, int $messageId, int $rating, ?string $text = null): int
    {
        $data = [
            'conversation_id' => $conversationId,
            'message_id'      => $messageId,
            'rating'          => $rating,
            'feedback_text'   => $text
        ];
        return $this->feedbackRepo->insert($data);
    }

    /**
     * Xuất báo cáo phân tích hiệu quả hoạt động AI (AI Analytics).
     */
    public function getAnalytics(): array
    {
        $db = new Database();
        
        // 1. Số cuộc hội thoại
        $db->query("SELECT COUNT(*) as total FROM chatbot_conversations");
        $convCount = (int)($db->single()->total ?? 0);

        // 2. Số câu hỏi từ khách hàng
        $db->query("SELECT COUNT(*) as total FROM chatbot_messages WHERE role = 'user'");
        $queryCount = (int)($db->single()->total ?? 0);

        // 3. Số lượt chuyển giao sang CSKH
        $db->query("SELECT COUNT(*) as total FROM chatbot_conversations WHERE status = 'transferred'");
        $transferCount = (int)($db->single()->total ?? 0);

        // 4. Mức độ hài lòng từ Feedback
        $feedbackStats = $this->feedbackRepo->getStatistics();

        $transferRate = $convCount > 0 ? round((100 * $transferCount) / $convCount, 1) : 0.0;
        $satisfaction = $feedbackStats['satisfaction'];

        return [
            'conversations_count' => $convCount,
            'questions_count'     => $queryCount,
            'transfer_count'      => $transferCount,
            'transfer_rate'       => $transferRate,
            'feedback_total'      => $feedbackStats['total'],
            'satisfaction_rate'   => $satisfaction
        ];
    }
}
