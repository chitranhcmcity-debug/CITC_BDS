<?php
/**
 * KnowledgeService – Quản lý cập nhật Cơ sở tri thức hệ thống.
 * Tuân thủ SOLID, Service Pattern.
 */
class KnowledgeService
{
    private KnowledgeRepository $repo;

    public function __construct()
    {
        require_once APP_ROOT . '/app/repositories/KnowledgeRepository.php';
        $this->repo = new KnowledgeRepository();
    }

    public function getRepo(): KnowledgeRepository
    {
        return $this->repo;
    }

    public function listArticles(string $category = ''): array
    {
        return $this->repo->listAll($category);
    }

    public function getArticle(int $id): ?stdClass
    {
        return $this->repo->findById($id);
    }

    public function addArticle(array $data): int
    {
        return $this->repo->insert($data);
    }

    public function updateArticle(int $id, array $data): bool
    {
        return $this->repo->update($id, $data);
    }

    public function deleteArticle(int $id): bool
    {
        return $this->repo->delete($id);
    }

    /**
     * Nhận chuỗi ngữ cảnh tri thức để chèn vào prompt hệ thống.
     */
    public function getKnowledgeContext(): string
    {
        return $this->repo->getActiveContext();
    }
}
